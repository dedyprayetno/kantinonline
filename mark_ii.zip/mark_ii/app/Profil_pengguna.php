<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profil_pengguna extends Model
{
    //
    protected $table = 'profil_pengguna';
    protected $fillable = ['pengguna_nim', 'tempat_lahir', 'tanggal_lahir', 'jenis_kelamin', 'alamat', 'no_hp', 'prodi'];

}