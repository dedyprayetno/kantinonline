<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Isi_saldo extends Model
{
    ///
    protected $table = 'isi_saldo';
    protected $fillable = [
    	'nim', 
    	'jumlah',
    	'file',
    	'status_konfirmasi',
        'konfirmasi'
	];

	public function pengguna()
    {
        return $this->belongsTo('App\Pengguna', 'nim');
    }
}
