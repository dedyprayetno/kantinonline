<?php

namespace App\Http\Middleware;

use Auth;
use Closure;

class MiddlewareKasir
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(Auth::user()->akses == "Kasir"){
            return $next($request);
        } else {
            return redirect()->route('masuk')
                             ->withErrors('Anda harus masuk sebagai Kasir untuk mengakses halaman ini.');
        }
        return $next($request);
    }
}
