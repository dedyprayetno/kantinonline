<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Contracts\Auth\Guard;

class RedirectIfAuthenticated
{
    protected $auth;
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function __construct(Guard $auth)
    {
        $this->auth = $auth;
    }
    public function handle($request, Closure $next, $guard = null)
    {
        if ($this->auth->check()) {
            if(Auth::user()->akses == "Admin"){
            return redirect()->route('beranda_admin')
                             ->withErrors('Anda tidak bisa Mengakses halaman tadi.');    
            }
            elseif(Auth::user()->akses == "Kasir"){
                return redirect()->route('beranda_kasir')
                                 ->withErrors('Anda tidak bisa Mengakses halaman tadi.');    
            }
            elseif(Auth::user()->akses == "Member"){
                return redirect()->route('beranda_member')
                                 ->withErrors('Anda tidak bisa Mengakses halaman tadi.');    
            }
            
        }

        return $next($request);
    }
}
