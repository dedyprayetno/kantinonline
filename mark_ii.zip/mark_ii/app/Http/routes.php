<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
Route::group(['middleware' => 'guest'], function(){
	Route::get('/', [
		'as'	=> 'beranda',
		'uses'	=> 'ControllerUtama@beranda'
	]);

	Route::get('/masuk', [
		'as'	=> 'masuk',
		'uses'	=> 'ControllerPengguna@masuk'
	]);
	Route::get('/daftar', [
			'as'	=> 'daftar',
			'uses'	=> 'ControllerPengguna@daftar'
	]);
	Route::post('/registrasi', [
		'as'	=> 'registrasi',
		'uses'	=> 'ControllerPengguna@registrasi'
	]);
	Route::get('/konfirmasi/{kode}', [
		'as'	=> 'konfirmasi',
		'uses'	=> 'ControllerPengguna@konfirmasi'
	]);
	Route::post('/otorisasi', [
		'as'	=> 'otorisasi',
		'uses'	=> 'ControllerPengguna@otorisasi'
	]);
	
});
Route::get('/keluar', [
		'as'	=> 'keluar',
		'uses'	=> 'ControllerPengguna@keluar'
	]);

Route::group(['middleware' => 'otorisasi'], function(){
	
	Route::group(['middleware' =>'Admin', 'prefix' => 'admin'], function(){
		Route::get('/beranda', [
			'as'	=> 'beranda_admin',
			'uses'	=> 'ControllerAdmin@beranda'
		]);

		//-------ADMIN MANAJEMEN MENU
		Route::get('/menu', [
			'as'	=> 'admin_menu',
			'uses'	=> 'ControllerMenu@admin_menu'
		]);
		Route::post('/menu/simpan', [
			'as'	=> 'admin_simpan_menu',
			'uses'	=> 'ControllerMenu@admin_simpan_menu'
		]);
		Route::get('/menu/edit/{id}', [
			'as'	=> 'admin_edit_menu',
			'uses'	=> 'ControllerMenu@admin_edit_menu'
		]);
		Route::post('/menu/ubah/{id}', [
			'as'	=> 'admin_ubah_menu',
			'uses'	=> 'ControllerMenu@admin_ubah_menu'
		]);
		Route::get('/menu/api_edit/{id}', [
			'as'	=> 'api_admin_edit_menu',
			'uses'	=> 'ControllerMenu@api_admin_edit_menu'
		]);
		Route::post('/menu/api_ubah/{id}', [
			'as'	=> 'api_admin_ubah_menu',
			'uses'	=> 'ControllerMenu@api_admin_ubah_menu'
		]);
		Route::get('/menu/hapus/{id}', [
			'as'	=> 'admin_hapus_menu',
			'uses'	=> 'ControllerMenu@admin_hapus_menu'
		]);



		//--------ADMIN MANAJEMEN ADMIN
		Route::get('/manajemen_admin', [
			'as'	=> 'admin_manajemen_admin',
			'uses'	=> 'ControllerPengguna@admin_manajemen_admin'
		]);
		Route::post('/manajemen_admin/registrasi', [
		'as'	=> 'registrasi_admin',
		'uses'	=> 'ControllerPengguna@registrasi_admin'
		]);

		//--------ADMIN MANAJEMEN ADMIN
		Route::get('/manajemen_kasir', [
			'as'	=> 'admin_manajemen_kasir',
			'uses'	=> 'ControllerPengguna@admin_manajemen_kasir'
		]);
		Route::post('/manajemen_kasir/registrasi', [
		'as'	=> 'registrasi_kasir',
		'uses'	=> 'ControllerPengguna@registrasi_kasir'
		]);

		//---------ADMIN ISI SALDO
		route::get('/isi_saldo',[
			'as' => 'admin_isi_saldo',
			'uses' => 'ControllerSaldo@admin_isi_saldo']);
		route::post('/isi_saldo',[
			'as' => 'admin_tambah_saldo',
			'uses' => 'ControllerSaldo@admin_tambah_saldo']);
		route::get('/konfirmasi_saldo/{id}',[
			'as' => 'admin_konfirmasi_saldo',
			'uses' => 'ControllerSaldo@admin_konfirmasi_saldo']);
		route::get('/tolak_saldo/{id}',[
			'as' => 'admin_tolak_saldo',
			'uses' => 'ControllerSaldo@admin_tolak_saldo']);

		//----------ADMIN TARIK SALDO

		route::get('/tarik_saldo',[
			'as' => 'admin_tarik_saldo',
			'uses' => 'ControllerSaldo@admin_tarik_saldo']);
		route::post('/tarik_saldo',[
			'as' => 'admin_ambil_saldo',
			'uses' => 'ControllerSaldo@admin_ambil_saldo']);
		route::get('/konfirmasi_tarik_saldo/{id}',[
			'as' => 'admin_konfirmasi_tarik_saldo',
			'uses' => 'ControllerSaldo@admin_konfirmasi_tarik']);
		route::get('/tolak_tarik_saldo/{id}',[
			'as' => 'admin_tolak_tarik_saldo',
			'uses' => 'ControllerSaldo@admin_tolak_tarik']);

		//--------LAPORAN
		route::get('/laporan_isi_saldo',[
			'as' => 'admin_laporan_isi_saldo',
			'uses' => 'ControllerLaporan@admin_laporan_isi_saldo']);
	});



	Route::group(['middleware' =>'Kasir', 'prefix' => 'kasir'], function(){
		Route::get('/beranda', [
			'as'	=> 'beranda_kasir',
			'uses'	=> 'ControllerKasir@beranda'
		]);
		Route::post('/beranda/api_tambah_keranjang/{id}', [
			'as'	=> 'api_tambah_keranjang',
			'uses'	=> 'ControllerTransaksi@api_tambah_keranjang'
		]);
		Route::get('/beranda/api_lihat_keranjang', [
			'as'	=> 'api_lihat_keranjang',
			'uses'	=> 'ControllerTransaksi@api_lihat_keranjang'
		]);	
	});

	Route::group(['middleware' => 'Member','prefix' => 'member'], function(){
		Route::get('/beranda', [
			'as'	=> 'beranda_member',
			'uses'	=> 'ControllerMember@beranda'
		]);
		Route::get('/isi_saldo', [
			'as'	=> 'member_isi_saldo',
			'uses'	=> 'ControllerSaldo@member_isi_saldo'
		]);
		Route::post('/isi_saldo', [
			'as'	=> 'simpan_member_isi_saldo',
			'uses'	=> 'ControllerSaldo@simpan_member_isi_saldo'
		]);
	});
});
// Route::get('sendemail', function () {

//     $data = array(
//         'name' => "Learning Laravel",
//     );

//     Mail::send('welcome', $data, function ($message) {

//         // $message->from('dedysosialmedia@gmail.com', 'Learning Laravel');

//         $message->to('dedyprayetno@gmail.com')->subject('Learning tunnLaravel test email');

//     });

//     return "Your email has been sent successfully";

// });
