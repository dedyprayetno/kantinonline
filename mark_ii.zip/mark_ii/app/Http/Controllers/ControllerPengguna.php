<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Pengguna;
use App\Profil_pengguna;
use App\Kasir;
use Auth;
use Mail;
use Response;
use URL;
use Validator;
use Session;

class ControllerPengguna extends Controller
{
	public static $aturan_validasi = [
        'nim' 			=> 'required|unique:pengguna,nim',
        'email' 		=> 'required|email|unique:pengguna,email',
        'username' 		=> 'required|unique:pengguna,username',
    	'password' 		=> 'required|confirmed|min:6',
	];


    public function masuk(){
        return view('masuk')
        ->with('judul_halaman', 'Masuk')
        ->with('nama_situs', 'Dedy');
    }

    public function otorisasi(Request $request){
        $aturan_validasi_masuk = [
            'username'      => 'required',
            'password'    => 'required|min:6'
        ];

        $validasi = Validator::make($request->all(), $aturan_validasi_masuk);
        if($validasi->fails()){
            return redirect()->route('masuk')
                    ->withErrors($validasi)
                    ->withInput();
        } else {
            if(Auth::attempt(['username' => $request->input('username'), 'password' => $request->input('password')])){
                
                if (Auth::user()->akses == "Admin"){
                    return redirect()->route('beranda_admin');
                }
                elseif (Auth::user()->akses == "Kasir"){
                    return redirect()->route('beranda_kasir');
                }
                elseif (Auth::user()->akses == "Member"){
                    return redirect()->route('beranda_member');
                }
            }
            
            else {
                return redirect()->route('masuk')
                                 ->withErrors('Username/Email atau kata sandi yang anda masukkan salah dan pastikan kalau anda sudah melakukan verifikasi akun melalui email.')
                                 ->withInput();
            }
        }
    }


    public function keluar(){
        Auth::logout();
        
        return redirect()->route('beranda');
    }

    public function daftar(){
        return view('daftar')
        ->with('judul_halaman', 'Daftar')
        ->with('nama_situs', 'Dedy');
    }
    public function registrasi(Request $request ){
         $validasi = Validator::make($request->only(['nim', 'nama', 'username', 'email', 'password','password_confirmation']), self::$aturan_validasi);
          if($validasi->fails()){
            return redirect()->route('daftar')
                    ->withErrors($validasi)
                    ->withInput();
        } else {
            $pengguna = $this->simpan_pengguna($request, 'Member');
            $profil = new Profil_pengguna;
            $profil->pengguna_nim = $request->input('nim');
            $profil->save();
 

           return redirect()->route('masuk');
        }
    }



    public function konfirmasi($kode){
        $pengguna = Pengguna::where('kode', '=', $kode)->first();

        if(count($pengguna) > 0){
            if($pengguna->aktif == 0){
                $pengguna->aktif = 1;
                $pengguna->save();

                return redirect()->route('masuk')
                                 ->with('pesan', 'Konfirmasi akun berhasil, silahkan masuk menggunakan akun anda.');
            } else {
                return redirect()->route('masuk')
                                 ->withErrors('Anda telah melakukan konfirmasi akun.');
            }
        } else {
            return redirect()->route('masuk')
                             ->withErrors('Konfirmasi akun gagal.');
        }
    }

    public static function simpan_pengguna($request, $akses){
        $data_pengguna = [
            'nim'           => $request->input('nim'),
            'nama'          => $request->input('nama'),
            'username'      => $request->input('username'),
            'email'         => $request->input('email'),
            'password'      => bcrypt($request->input('password')),
            'akses'         => $akses,
            'kode'          => str_random(30),
            'verifikasi'    => 'tidak'
        ];
        
        $pengguna = Pengguna::create($data_pengguna);

        return (($pengguna) ? $pengguna : null);
    }

    // Manajemen Admin
    public function admin_manajemen_admin(){
        $pengguna = Pengguna::all();
        return view('admin.manajemen_admin.manajemen_admin')
                ->with('judul_halaman', 'Manajemen Admin')
                ->with('pengguna', $pengguna);
    }
    public function registrasi_admin(Request $request ){
         $validasi = Validator::make($request->only(['nim', 'nama', 'username', 'email', 'password','password_confirmation']), self::$aturan_validasi);
          if($validasi->fails()){
            return redirect()->route('admin_manajemen_admin')
                    ->withErrors($validasi)
                    ->withInput();
        } else {
            $pengguna = $this->simpan_pengguna($request, 'Admin');
 
            Session::flash('pesan', 'Berhasil menambahkan Admin baru');
           return redirect()->route('admin_manajemen_admin');
        }
    }

    //Manajemen Kasir
    public function admin_manajemen_kasir(){
        $pengguna = Pengguna::all();
        return view('admin.manajemen_kasir.manajemen_kasir')
                ->with('judul_halaman', 'Manajemen Kasir')
                ->with('pengguna', $pengguna);
    }
    public function registrasi_kasir(Request $request ){
         $validasi = Validator::make($request->only(['nim', 'nama', 'username', 'email', 'password','password_confirmation']), self::$aturan_validasi);
          if($validasi->fails()){
            return redirect()->route('admin_manajemen_kasir')
                    ->withErrors($validasi)
                    ->withInput();
        } else {
            $pengguna = $this->simpan_pengguna($request, 'Kasir');
            $profil = new Profil_pengguna;
            $profil->pengguna_nim = $request->input('nim');
            $profil->save();
            $kasir = new Kasir;
            $kasir->nim = $request->input('nim');
            $kasir->save();

 
            Session::flash('pesan', 'Berhasil menambahkan kasir baru');
            return redirect()->route('admin_manajemen_kasir');
        }
    }

}
