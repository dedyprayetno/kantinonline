<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Menu;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Validator;
use Redirect;
use Auth;
use Session;

class ControllerMenu extends Controller
{
    //
    public function admin_menu(){
        $data_menu = Menu::all();
        return view('admin.menu.menu')
                ->with('judul_halaman', 'Manajemen Menu')
                ->with('data_menu', $data_menu);
    }
    public function admin_simpan_menu(Request $request)
	{
        $rules = array(
                'nama_menu' => 'required',
                'tipe' => 'required',
                'status' => 'required',
                'harga' => 'required|numeric',
        );
	 
        $validator = Validator::make($request->all(), $rules);
 
        if ($validator->fails()) {     
            return redirect()->route('admin_menu')->withErrors($validator)->withInput();
        } 
        else {
        	if ($request->hasFile('image')) {
					$destinationPath = 'images/menu'; // upload path
					$extension = $request->file('image')->getClientOriginalExtension(); // getting image extension
					$fileName =  $request->input('tipe').'_'.$request->input('nama_menu').'.'.$extension; // renameing image
					$request->file('image')->move($destinationPath, $fileName); // uploading file to given path
					// sending back with message
					$menu = new Menu;
					$menu->nama_menu = $request->input('nama_menu');
					$menu->tipe = $request->input('tipe');
                    $menu->deskripsi = $request->input('deskripsi');
					$menu->file = $fileName;
					$menu->harga = $request ->input('harga');
					$menu->approve = Auth::user()->username;
					$menu->status = $request->input('status');
					$menu->save();

					// return var_dump($kategori_user->save());
					Session::flash('pesan', 'Data Berhasil Ditambahkan');
					return redirect()->route('admin_menu');
			    }
			    else {
			      // sending back with error message.
			    	$menu = new Menu;
					$menu->nama_menu = $request->input('nama_menu');
					$menu->tipe = $request->input('tipe');
                    $menu->deskripsi = $request->input('deskripsi');
					$menu->harga = $request ->input('harga');
					$menu->approve = Auth::user()->username;
					$menu->status = $request->input('status');
					$menu->save();
			      Session::flash('pesan', 'Data Berhasil dimasukkan NOTE: Foto belum dimasukan');
			      return redirect()->route('admin_menu');
			    }                 
	     }
	}

    public function admin_edit_menu ($id){
        $data_menu = Menu::findOrFail($id);
        return view('admin.menu.edit_menu')->with('judul_halaman', 'Edit Menu')
                ->with('data_menu', $data_menu);
    }

	public function admin_ubah_menu(Request $request, $id)
    {
        $rules = array(
                'nama_menu' => 'required',
                'tipe' => 'required',
                'status' => 'required',
                'harga' => 'required|numeric',
        );
     
        $validator = Validator::make($request->all(), $rules);
 
        if ($validator->fails()) {     
            return redirect()->route('admin_edit_menu')->withErrors($validator)->withInput();
        } 
        else {
            if ($request->hasFile('image')) {
                    $destinationPath = 'photo/menu'; // upload path
                    $extension = $request->file('image')->getClientOriginalExtension(); // getting image extension
                    $fileName =  $request->input('tipe').'_'.$request->input('nama_menu').'.'.$extension; // renameing image
                    $request->file('image')->move($destinationPath, $fileName); // uploading file to given path
                    // sending back with message
                    $menu = Menu::find($id);
                    $menu->nama_menu = $request->input('nama_menu');
                    $menu->tipe = $request->input('tipe');
                    $menu->deskripsi = $request->input('deskripsi');
                    $menu->file = $fileName;
                    $menu->harga = $request ->input('harga');
                    $menu->status = $request->input('status');
                    $menu->save();

                    Session::flash('pesan', 'Data Berhasil Diubah');
                    return redirect()->route('admin_menu');
                }
                else {
                  // sending back with error message.
                    $menu = Menu::find($id);
                    $menu->nama_menu = $request->input('nama_menu');
                    $menu->tipe = $request->input('tipe');
                    $menu->deskripsi = $request->input('deskripsi');
                    $menu->harga = $request ->input('harga');
                    $menu->status = $request->input('status');
                    $menu->save();
                  Session::flash('pesan', 'Data Berhasil dimasukkan NOTE: Foto Tidak diubah');
                  return redirect()->route('admin_menu');
                }                 
         }
    
    }


    /*public function api_admin_edit_menu($id){
        $menu = Menu::findOrFail($id);

        return json_encode($menu);
    }*/

    /*public function api_admin_ubah_menu(Request $request, $id)
    {
        $menu = Menu::find($id);
        $menu->nama_menu = $request->input('nama_menu');
        $menu->tipe = $request->input('tipe');
        $menu->deskripsi = $request->input('deskripsi');
        $menu->harga = $request ->input('harga');
        $menu->status = $request->input('status');
        $menu->save();

        return json_encode("sukses");
    }*/

	public function admin_hapus_menu($id){
        $menu = Menu::findOrFail($id);
        $menu->delete();
        
        return redirect()->route('admin_menu')
                ->with('pesan', 'Data berhasil dihapus');
    }
}
