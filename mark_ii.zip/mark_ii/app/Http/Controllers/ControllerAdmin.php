<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Pengguna;

class ControllerAdmin extends Controller
{
    //
    public function beranda(){
    	$count_admin = Pengguna::where('akses','=','Admin')->count();
    	$count_kasir = Pengguna::where('akses','=','Kasir')->count();
    	$count_member = Pengguna::where('akses','=','Member')->count();
    	return view('admin.beranda')
    	->with('judul_halaman', 'Beranda')
    	->with('jumlah_admin', $count_admin)
    	->with('jumlah_kasir', $count_kasir)
    	->with('jumlah_member', $count_member);
    }
}
