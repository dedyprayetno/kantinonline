<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Validator;
use Redirect;
use Session;
use Auth;
use App\Isi_saldo;
use App\Pengguna;
use App\Tarik_saldo;

class ControllerSaldo extends Controller
{
    //Isi Saldo
    public function admin_isi_saldo(){
    	$data_saldo = Isi_saldo::where('status_konfirmasi', '=', 'Belum')->get();
    	return view('admin.isi_saldo.isi_saldo')
	    	->with('judul_halaman', 'Isi Saldo')
            ->with('isi_saldo', $data_saldo);
    }

    public function admin_tambah_saldo(Request $request)
	{
        $rules = array(
                'nim' => 'required',
                'jumlah' => 'required',
        );
	 
        $validator = Validator::make($request->all(), $rules);
 
        if ($validator->fails()) {     
            return redirect()->route('admin_isi_saldo')->withErrors($validator)->withInput();
        } 
        else {
        	
			$saldo = new Isi_saldo;
			$saldo->nim = $request->input('nim');
			$saldo->jumlah = $request->input('jumlah');
			$saldo->status_konfirmasi = 'Sudah';
			$saldo->konfirmasi = Auth::user()->username;
			$saldo->save();
			$data_pengguna = Pengguna::findOrFail($request->input('nim'));
        	$data_pengguna->saldo = $data_pengguna->saldo + $request->input('jumlah');
        	$data_pengguna->save();

				// return var_dump($kategori_user->save());
				Session::flash('pesan', 'Data Berhasil Ditambahkan');
				return redirect()->route('admin_isi_saldo');
	   }
	}
	public function admin_konfirmasi_saldo($id){
		$saldo = Isi_saldo::findOrFail($id);
		$data_pengguna = Pengguna::find($saldo->nim);
		$data_pengguna->saldo = $data_pengguna->saldo + $saldo->jumlah;
		$data_pengguna->save();
		$saldo->status_konfirmasi = 'Sudah';
		$saldo->konfirmasi = Auth::user()->username;
		$saldo->save();
		Session::flash('pesan', 'Konfirmasi Saldo Berhasil');
		return redirect()->route('admin_isi_saldo');

	}
	public function admin_tolak_saldo($id){
		$saldo = Isi_saldo::findOrFail($id);
		$saldo->status_konfirmasi = 'Tolak';
		$saldo->konfirmasi = Auth::user()->username;
		$saldo->save();
		
		Session::flash('pesan', 'Penolakan Saldo Berhasil');
		return redirect()->route('admin_isi_saldo');
	}

	public function member_isi_saldo(){
    	return view('member.isi_saldo')
	    	->with('judul_halaman', 'Isi Saldo');
	}
	public function simpan_member_isi_saldo(Request $request){
    	$rules = array(
                'jumlah' => 'required',
        );
	 
        $validator = Validator::make($request->all(), $rules);
 
        if ($validator->fails()) {     
            return redirect()->route('member_isi_saldo')->withErrors($validator)->withInput();
        } 
        else {
        	if ($request->hasFile('image')) {
				$destinationPath = 'images/isi_saldo'; // upload path
				$extension = $request->file('image')->getClientOriginalExtension(); // getting image extension
				$fileName =  Auth::user()->nim.'_'.date('dd:mm:yyyy').'.'.$extension; // renameing image
				$request->file('image')->move($destinationPath, $fileName); // uploading file to given path
				// sending back with message
				$saldo = new Isi_saldo;
				$saldo->nim = Auth::user()->nim;
				$saldo->jumlah = $request->input('jumlah');
				$saldo->status_konfirmasi = 'Belum';
				$saldo->save();

				// return var_dump($kategori_user->save());
				Session::flash('pesan', 'Data Berhasil Ditambahkan');
				return redirect()->route('beranda_member');
			}
	   }
	}

	//======================================================

	//TARIK SALDO
	public function admin_tarik_saldo(){
		$data_saldo = Tarik_saldo::where('status_konfirmasi', '=', 'Belum')->get();
    	return view('admin.tarik_saldo.tarik_saldo')
	    	->with('judul_halaman', 'Tarik Saldo')
            ->with('tarik_saldo', $data_saldo);

	}

	public function admin_ambil_saldo(Request $request)
	{
        $rules = array(
                'nim' => 'required',
                'jumlah' => 'required',
        );
	 
        $validator = Validator::make($request->all(), $rules);
 
        if ($validator->fails()) {     
            return redirect()->route('admin_isi_saldo')->withErrors($validator)->withInput();
        } 
        else {
        	
			$saldo = new Isi_saldo;
			$saldo->nim = $request->input('nim');
			$saldo->jumlah = $request->input('jumlah');
			$saldo->status_konfirmasi = 'Sudah';
			$saldo->konfirmasi = Auth::user()->username;
			$saldo->save();
			$data_pengguna = Pengguna::findOrFail($request->input('nim'));
        	$data_pengguna->saldo = $data_pengguna->saldo + $request->input('jumlah');
        	$data_pengguna->save();

				// return var_dump($kategori_user->save());
				Session::flash('pesan', 'Data Berhasil Ditambahkan');
				return redirect()->route('admin_isi_saldo');
	   }
	}
}
