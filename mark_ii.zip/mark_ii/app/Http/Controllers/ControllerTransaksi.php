<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Menu;
use App\Kasir;
use App\Transaksi;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Validator;
use Redirect;
use Auth;
use Session;


class ControllerTransaksi extends Controller
{
    //
    public function api_tambah_keranjang($id){

    	$menu = Menu::find($id);

    	$check =['id_group_trans' => $id, 'id_kasir' => Auth::user()->pengguna_kasir->id];
    	$results = Transaksi::where($check)->first();
    	if ($results)
    	{
    		$trans = $results;
    		$trans->increment('jumlah');
    		$trans->harga = $menu->harga;
    		$trans->status_konfirmasi = "Belum Dibayar";
    		$trans->total = $trans->total = $trans->harga * $trans->jumlah;
            $trans->save();
    	}
    	else{

    		$trans = new Transaksi;
    		$trans->id_kasir = Auth::user()->pengguna_kasir->id;
    		$trans->harga = $menu->harga;
    		$trans->jumlah = 1;
            $trans->status_konfirmasi = "Belum Dibayar";
    		$trans->id_group_trans = $id;
    		$trans->total = $trans->harga * $trans->jumlah;
    		$trans->save(); 
    	}
        $data_menu = Transaksi::where('status_konfirmasi', '=', 'Belum Dibayar')->where('id_kasir', '=', Auth::user()->pengguna_kasir->id)->sum('jumlah');
            return json_encode($data_menu);

    	
    }
    public function api_lihat_keranjang(){
        $data_menu = Transaksi::where('status_konfirmasi', '=', 'Belum Dibayar')->where('id_kasir', '=', Auth::user()->pengguna_kasir->id)->first();
        return json_encode($data_menu);

    }
}
