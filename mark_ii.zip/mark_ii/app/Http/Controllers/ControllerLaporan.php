<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Validator;
use Redirect;
use Session;
use Auth;
use App\Isi_saldo;
use App\Pengguna;
use App\Tarik_saldo;

class ControllerLaporan extends Controller
{
    //
    public function admin_laporan_isi_saldo(){
    	$data_saldo = Isi_saldo::all();
    	return view('admin.laporan.laporan_isi_saldo')
	    	->with('judul_halaman', 'Laporan Isi Saldo')
            ->with('data_isi_saldo', $data_saldo);
    }
}
