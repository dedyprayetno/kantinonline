<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Menu;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Validator;
use Redirect;
use Auth;
use Session;
use App\Transaksi;


class ControllerKasir extends Controller
{
    //
    public function beranda(){
    	$menu = Menu::all();
    	$data_menu = Transaksi::where('status_konfirmasi', '=', 'Belum Dibayar')->where('id_kasir', '=', Auth::user()->pengguna_kasir->id)->sum('jumlah');
    	return view('kasir.beranda')
    	->with('judul_halaman', 'Beranda')
    	->with('menu', $menu)
    	->with('keranjang', $data_menu);
    }
}
