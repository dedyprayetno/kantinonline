<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class ControllerMember extends Controller
{
    //
     public function beranda(){
    	return view('member.beranda')
    	->with('judul_halaman', 'Beranda');
    }
}
