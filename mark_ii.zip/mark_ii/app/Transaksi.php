<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaksi extends Model
{
    //

    protected $table = 'transaksi';
    protected $fillable = [
    	'id_kasir',
    	'harga',
    	'jumlah',
    	'total',
    	'nim',
    	'status_konfirmasi',
    	'id_group_trans'

	];

	public function kasir_menu()
    {
        return $this->belongsTo('App\Kasir', 'nim');
    }
}
