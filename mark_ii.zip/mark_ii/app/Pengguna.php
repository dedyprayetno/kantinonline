<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Foundation\Auth\Access\Authorizable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;

class Pengguna extends Model implements AuthenticatableContract,
                                    AuthorizableContract,
                                    CanResetPasswordContract
{
    use Authenticatable, Authorizable, CanResetPassword;
    //
    protected $table = 'pengguna';
    protected $primaryKey ='nim';
    public $incrementing = false;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['nim', 'nama', 'username', 'email', 'password', 'pin', 'rfid', 'status', 'akses', 'kode', 'saldo', 'verifikasi', 'status'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['password', 'remember_token', 'pin', 'rfid'];

    public function profil()
    {
        return $this->hasOne('App\Profil_pengguna', 'pengguna_nim');
    }

    public function isi_saldo()
    {
        return $this->hasMany('App\Isi_saldo', 'nim');
    }
    public function tarik_saldo()
    {
        return $this->hasMany('App\tarik_saldo', 'nim');
    }

    public function pengguna_kasir()
    {
        return $this->hasOne('App\Kasir', 'nim');
    }

    
}
