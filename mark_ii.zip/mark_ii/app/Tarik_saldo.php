<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tarik_saldo extends Model
{
    //
    protected $table = 'tarik_saldo';
    protected $fillable = [
    	'nim', 
    	'jumlah',
    	'status_konfirmasi',
        'konfirmasi'
	];

	public function pengguna()
    {
        return $this->belongsTo('App\Pengguna', 'nim');
    }
}
