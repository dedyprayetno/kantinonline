<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    //
    //
    protected $table = 'menu';
    protected $fillable = [
    	'nama_menu',
    	'deskripsi',
    	'tipe',
    	'file',
    	'harga',
    	'request_from',
    	'aprrove',
    	'status'

	];

    public function kasir()
    {
        return $this->belongsToMany('App/Kasir');
    }
}
