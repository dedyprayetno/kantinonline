<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kasir extends Model
{
    //
    protected $table = 'kasir';
    protected $fillable = [
        'nim',
    	'nama_kasir',
    	'deskripsi_kasir',
    	'avatar',
    	'gambar_kasir'

    	];
    public $timestamps = false;


    public function menu()
    {
        return $this->belongsToMany('App/Menu');
    }

    public function transaksi()
    {
        return $this->hasMany('App/Transaksi');
    }
}
