<?php $__env->startSection('customcss'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>


<?php if(Session::has('pesan')): ?>
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <?php echo e(Session::get('pesan')); ?>

</div>
<?php endif; ?>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>