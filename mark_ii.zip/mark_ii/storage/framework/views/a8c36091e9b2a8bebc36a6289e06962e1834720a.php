<?php $__env->startSection('customcss'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('kepala'); ?>
    <a href="#" type="button" class="btn btn-success">
        Tambah Kategori
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<?php if(Session::has('pesan')): ?>
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <?php 
    $msg   = 'test';
    $head = 'Ada beberapa notifikasi';
    ?>
</div>
<?php endif; ?>

<div class="table-responsive">
<table class="table table-striped table-bordered table-hover dataTables-example">
<thead>
<tr>
    <th style="text-align:center;" width="20px">No</th>
    <th>Nama</th>
    <th>Tipe</th>
    <th>Image</th>
    <th>Deskripsi</th>
    <th>Harga</th>
    <th>Status</th>
    <th style="text-align:center;" width="100px">Aksi</th>
</tr>
</thead>
<tbody>
<?php $no = 1; ?>
<?php foreach($menu as $menu): ?>
<tr>
    <td><?php echo e($no); ?></td>
    <td><?php echo e($menu->nama_menu); ?></td>
    <td><?php echo e($menu->tipe); ?></td>
    <td><?php if($menu->file != ""): ?>
        <a href="<?php echo e(URL::to('/')); ?>/photo/menu/<?php echo e($menu->file); ?>" target="_blank" />image</a>
        <?php endif; ?>
        </td>
    <td><?php echo e($menu->deskripsi); ?></td>
    <td>Rp <?php echo e($menu->harga); ?></td>
    <td><?php echo e($menu->status); ?></td>
    <td><a href="<?php echo e(URL::route('edit_manajemen_menu', $menu->id)); ?>" class="btn btn-primary"><i class="fa fa-edit"></i> Edit</a>
        <a onClick="konfirmasiHapus('<?php echo e(URL::route('hapus_manajemen_menu', $menu->id)); ?>')" class="btn btn-danger"><i class="fa fa-trash-o"></i> Hapus</a></td>
</tr>
<?php $no++; ?>
<?php endforeach; ?>  
</tbody>
<tfoot>
<tr>
    <th style="text-align:center;" width="20px">No</th>
    <th>Nama</th>
    <th>Tipe</th>
    <th>Image</th>
    <th>Deskripsi</th>
    <th>Harga</th>
    <th>Status</th>
    <th style="text-align:center;" width="100px">Aksi</th>
</tr>
</tfoot>
</table>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>

<script type="text/javascript">
        $(document).ready(function() {
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    timeOut: 4000,
                    positionClass : 'toast-top-right'
                };
                toastr.success('Responsive Admin Theme', 'Welcome to INSPINIA');

            }, 1300);
        }
</script>    
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>