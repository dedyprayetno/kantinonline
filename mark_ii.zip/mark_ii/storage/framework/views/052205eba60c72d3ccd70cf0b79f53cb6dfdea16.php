<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo e($judul_halaman); ?> | Kantin Online</title>
     <!-- Bootstrap core CSS -->
    <?php echo Html::style('css/bootstrap.css'); ?>


    <!-- Animation CSS -->
    <?php echo Html::style('css/animate.css'); ?>

    <?php echo Html::style('font-awesome/css/font-awesome.min.css'); ?>


    <?php echo Html::style('css/plugins/dataTables/datatables.min.css'); ?>


    <!-- Toastr style -->
    <?php echo Html::style('css/plugins/toastr/toastr.min.css'); ?>


    <!-- Custom styles for this template -->
    <?php echo Html::style('css/style.css'); ?>


    <?php echo $__env->yieldContent('customcss'); ?>
</head>

<body class="">

    <div id="wrapper">

    <!-- Navigasi-->
    <?php echo $__env->make('layout.admin._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <!-- Header-->
        <?php echo $__env->make('layout.admin._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2><?php echo e($judul_halaman); ?></h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo e(URL::route('beranda_admin')); ?>">Admin</a>
                        </li>
                        <li class="active">
                            <strong><?php echo e($judul_halaman); ?></strong>
                        </li>
                    </ol>
                </div>
                
            </div>

            <div class="wrapper wrapper-content animated fadeInRight">
               <div class="row">
                   <div class="col-lg-12">
                       <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <?php echo $__env->yieldContent('kepala'); ?>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                            <?php echo $__env->yieldContent('konten'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer">
                <div class="pull-right">
                    10GB of <strong>250GB</strong> Free.
                </div>
                <div>
                    <strong>Copyright</strong> Example Company &copy; 2014-2015
                </div>
            </div>

        </div>
    </div>



    <!-- Mainly scripts -->
    <?php echo Html::script('js/jquery-2.1.1.js'); ?>

    <?php echo Html::script('js/bootstrap.min.js'); ?>

    <?php echo Html::script('js/plugins/metisMenu/jquery.metisMenu.js'); ?>

    <?php echo Html::script('js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>


    <?php echo Html::script('js/plugins/dataTables/datatables.min.js'); ?>


    <!-- Toastr -->
    <?php echo Html::script('js/plugins/toastr/toastr.min.jss'); ?>


    <!-- Custom and plugin javascript -->
    <?php echo Html::script('js/inspinia.js'); ?>

    <?php echo Html::script('js/plugins/pace/pace.min.js'); ?>


    <script type="text/javascript">
        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    { extend: 'copy'},
                    {extend: 'csv'},
                    {extend: 'excel', title: 'ExampleFile'},
                    {extend: 'pdf', title: 'ExampleFile'},

                    {extend: 'print',
                     customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });
        }
    </script>

    <?php echo $__env->yieldContent('customjs'); ?>


</body>

</html>
