<div class="modal inmodal" id="isi_saldo_member" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content animated rollIn">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">Isi Saldo</h4>
                <small class="font-bold">Isi form dibawah ini untuk menambahkan Saldo ke Member</small>
            </div>
            <div class="modal-body">
               <div class="row">
                    <div class="form-group">
                        <?php echo e(Form::open(array('route' => 'admin_tambah_saldo', 'files'=> true))); ?>

                        <?php echo e(Form::label('', 'nim', array('class' => 'col-sm-4 control-label'))); ?>

                        <div class="col-sm-5">
                            <?php echo e(Form::text('nim', null, array('class' => 'form-control','placeholder'=>'masukkan NIM'))); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <?php echo e(Form::label('', 'Jumlah (RP)', array('class' => 'col-sm-4 control-label'))); ?>

                        <div class="col-sm-5">
                            <?php echo e(Form::text('jumlah', null, array('class' => 'form-control','placeholder'=>'masukkan Jumlah'))); ?>

                        </div>
                    </div>
                </div>
            </div>
            <?php echo csrf_field(); ?>

            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
</div>