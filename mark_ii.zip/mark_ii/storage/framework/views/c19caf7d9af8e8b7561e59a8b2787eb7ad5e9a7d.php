<div class="modal inmodal" id="tambah_menu" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content animated rollIn">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">Tambah Menu</h4>
                <small class="font-bold">Isi form menu dibawah ini untuk menambahkan menu</small>
            </div>
            <div class="modal-body">
               <div class="row">
                    <div class="form-group">
                        <?php echo e(Form::open(array('route' => 'admin_simpan_menu', 'files'=> true))); ?>

                        <?php echo e(Form::label('', 'Nama Menu', array('class' => 'col-sm-4 control-label'))); ?>

                        <div class="col-sm-5">
                            <?php echo e(Form::text('nama_menu', null, array('class' => 'form-control','placeholder'=>'masukkan Nama Menu'))); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <?php echo e(Form::label('tipe', 'Tipe', array ('class' => 'col-sm-4 control-label'))); ?>

                        <div class="col-sm-5">
                        <?php echo e(Form::select('tipe', array('Makanan' => 'Makanan', 'Minuman' => 'Minuman', 'Cemilan' => 'Cemilan'), null, array('class' => 'form-control','placeholder'=>'Tipe Makanan'))); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <?php echo e(Form::label('tipe', 'Berkas Gambar', array ('class' => 'col-sm-4 control-label'))); ?>

                        <div class="col-sm-5">
                         <?php echo e(Form::file('image', null, array('class'=> 'form-control'))); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <?php echo e(Form::label('', 'Harga', array('class' => 'col-sm-4 control-label'))); ?>

                        <div class="col-sm-5">
                            <?php echo e(Form::text('harga', null, array('class' => 'form-control','placeholder'=>'masukkan Harga Menu'))); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <?php echo e(Form::label('', 'Deskripsi', array('class' => 'col-sm-4 control-label'))); ?>

                        <div class="col-sm-5">
                            <?php echo e(Form::textarea('deskripsi', null, array('class' => 'form-control','placeholder'=>'masukkan Deskripsi','rows' => '3'))); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <?php echo e(Form::label('status', 'Status', array ('class' => 'col-sm-4 control-label'))); ?>

                        <div class="col-sm-5">
                        <?php echo e(Form::select('status', array('Aktif' => 'Aktif', 'Nonaktif' => 'Non Aktif'), null, array('class' => 'form-control','placeholder'=>'Status'))); ?>

                        </div>
                    </div>
                </div>
            </div>
            <?php echo csrf_field(); ?>

            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
</div>