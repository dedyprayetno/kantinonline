<?php $__env->startSection('customcss'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('kepala'); ?>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah_menu">
        Tambah
</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

<div class="table-responsive">
<table class="table table-striped table-bordered table-hover dataTables-example datatables">
<thead>
<tr>
    <th style="text-align:center;" width="20px">No</th>
    <th>Nama</th>
    <th>Tipe</th>
    <th>Image</th>
    <th>Harga</th>
    <th>Konfirmasi Oleh</th>
    <th>Status</th>
    <th>Aksi</th>
</tr>
</thead>
<tbody>
<?php $no = 1; ?>
<?php foreach($data_menu as $menu): ?>
<tr>
    <td><?php echo e($no); ?></td>
    <td><?php echo e($menu->nama_menu); ?></td>
    <td><?php echo e($menu->tipe); ?></td>
    <td><?php if($menu->file != ""): ?>
        <a href="<?php echo e(URL::to('/')); ?>/images/menu/<?php echo e($menu->file); ?>" target="_blank" />image</a>
        <?php endif; ?>
        </td>
    <td>Rp <?php echo e($menu->harga); ?></td>
    <td><?php echo e($menu->approve); ?></td>
    <td><?php echo e($menu->status); ?></td>
    <td>  <a href="<?php echo e(URL::route('admin_edit_menu', $menu->id)); ?>" class="btn btn-warning"><i class="fa fa-edit"></i> edit</a>
          <a onClick="konfirmasiHapus('<?php echo e(URL::route('admin_hapus_menu', $menu->id)); ?>', '<?php echo e($menu->nama_menu); ?>')" class="btn btn-danger"><i class="fa fa-trash-o"></i> Hapus</a></td>
        
</tr>
<?php $no++; ?>
<?php endforeach; ?>  
</tbody>
<tfoot>
<tr>
    <th style="text-align:center;" width="20px">No</th>
    <th>Nama</th>
    <th>Tipe</th>
    <th>Image</th>
    <th>Harga</th>
    <th>Konfirmasi Oleh</th>
    <th>Status</th>
    <th>Aksi</th>
</tr>
</tfoot>
</table>
</div>


<?php echo $__env->make('admin.menu.tambah_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>

    <!-- <script type="text/javascript">
      function editMenu(url, nama, tipe, harga, deskripsi){
        $.ajax({
          method: "GET",
          url: url,
          dataType: "json",
          success: function(data){
            console.log(data);
            // $('#edit_menu form').attr('action', url);
            $('#edit_menu input[name=nama_menu]').val(data.nama_menu);
            $('#edit_menu input[name=url]').val("");
            $('#edit_menu select[name=tipe]').val(tipe);
            $('#edit_menu input[name=harga]').val(harga);
            $('#edit_menu textarea[name=deskripsi]').val(deskripsi);
            $('#edit_menu').modal('show');
          }
        });
      }
      $(document).ready(function(){
        $("#form_edit_menu").submit(function(event){
          event.preventDefault();
          console.log('ok');
          $.ajax({
            method: "POST",
            url: $("#form_edit_menu input[name=url").val(),
            data: $(this).serialize(),
            dataType: "json",
            success: function(data){
              console.log(data);
            }
          });
    
          // return false;
        });
      });
    </script> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>