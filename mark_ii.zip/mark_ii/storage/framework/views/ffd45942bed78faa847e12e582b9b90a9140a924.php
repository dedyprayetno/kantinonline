<?php $__env->startSection('customcss'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>


<?php if(Session::has('pesan')): ?>
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <?php echo e(Session::get('pesan')); ?>

</div>
<?php endif; ?>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
		<div class="col-lg-3">
		    <div class="widget style1 lazur-bg">
		        <div class="row">
		            <div class="col-xs-4">
		                <i class="fa fa-user fa-5x"></i>
		            </div>
		            <div class="col-xs-8 text-right">
		                <span> Admin </span>
		                <h2 class="font-bold"><?php echo e($jumlah_admin); ?></h2>
		            </div>
		        </div>
		    </div>
		</div>
		<div class="col-lg-3">
		    <div class="widget style1 lazur-bg">
		        <div class="row">
		            <div class="col-xs-4">
		                <i class="fa fa-user fa-5x"></i>
		            </div>
		            <div class="col-xs-8 text-right">
		                <span> Kasir </span>
		                <h2 class="font-bold"><?php echo e($jumlah_kasir); ?></h2>
		            </div>
		        </div>
		    </div>
		</div>
		<div class="col-lg-3">
		    <div class="widget style1 lazur-bg">
		        <div class="row">
		            <div class="col-xs-4">
		                <i class="fa fa-user fa-5x"></i>
		            </div>
		            <div class="col-xs-8 text-right">
		                <span> Member </span>
		                <h2 class="font-bold"><?php echo e($jumlah_member); ?></h2>
		            </div>
		        </div>
		    </div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>