<div class="modal inmodal" id="tambah_admin" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content animated rollIn">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">Tambah Admin</h4>
                <small class="font-bold">Isi form Admin dibawah ini untuk menambahkan Admin</small>
            </div>
            <div class="modal-body">
               <div class="row">
                     <?php echo Form::open(array('route' => 'registrasi_admin', 'class' => 'm-t')); ?>

                    <div class="form-group">
                        <?php echo e(Form::text('nim', null, array('class' => 'form-control','placeholder'=>'Masukan NIM/NIK/NIP'))); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::text('nama', null, array('class' => 'form-control','placeholder'=>'Masukan Nama Lengkap'))); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::text('username', null, array('class' => 'form-control','placeholder'=>'Masukan Username'))); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::email('email', null, array('class' => 'form-control','placeholder'=>'Masukan Email'))); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::password('password', array('class' => 'form-control','placeholder'=>'Masukan Password'))); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::password('password_confirmation', array('class' => 'form-control','placeholder'=>'Ulangi Password'))); ?>

                    </div>
                </div>
            </div>
            <?php echo csrf_field(); ?>

            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>