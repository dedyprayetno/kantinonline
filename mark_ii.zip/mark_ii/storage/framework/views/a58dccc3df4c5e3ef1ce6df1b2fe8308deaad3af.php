<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <title><?php echo e($judul_halaman); ?> | Kantin Online</title>
     <!-- Bootstrap core CSS -->
    <?php echo Html::style('css/bootstrap.css'); ?>


    <!-- Animation CSS -->
    <?php echo Html::style('css/animate.css'); ?>

    <?php echo Html::style('font-awesome/css/font-awesome.min.css'); ?>


    <?php echo Html::style('css/plugins/dataTables/datatables.min.css'); ?>


    <!-- Toastr style -->
    <?php echo Html::style('css/plugins/toastr/toastr.min.css'); ?>


    <!-- Custom styles for this template -->
    <?php echo Html::style('css/style.css'); ?>

    <?php echo Html::style('css/plugins/codemirror/codemirror.css'); ?>

    <?php echo Html::style('css/plugins/codemirror/ambiance.css'); ?>


    <?php echo $__env->yieldContent('customcss'); ?>
    

</head>

<body class="fixed-sidebar no-skin-config full-height-layout">

    <div id="wrapper">

    <?php echo $__env->make('layout.member._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <?php echo $__env->make('layout.member._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Outlook view</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Layouts</a>
                        </li>
                        <li class="active">
                            <strong>Outlook view</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>

                 <div class="wrapper wrapper-content animated fadeInRight">
                   <div class="row">
                       <div class="col-lg-12">
                           <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <?php echo $__env->yieldContent('kepala'); ?>
                                    <div class="ibox-tools">
                                        <a class="collapse-link">
                                            <i class="fa fa-chevron-up"></i>
                                        </a>
                                        <a class="close-link">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="ibox-content">
                                <?php echo $__env->yieldContent('konten'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



            </div>

        <div class="footer">
            <div class="pull-right">
                10GB of <strong>250GB</strong> Free.
            </div>
            <div>
                <strong>Copyright</strong> Example Company &copy; 2016
            </div>
        </div>

        </div>
        </div>



    <!-- Mainly scripts -->
    <?php echo Html::script('js/jquery-2.1.1.js'); ?>

    <?php echo Html::script('js/bootstrap.min.js'); ?>

    <?php echo Html::script('js/plugins/metisMenu/jquery.metisMenu.js'); ?>

    <?php echo Html::script('js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>


    <?php echo Html::script('js/plugins/dataTables/datatables.min.js'); ?>


    <!-- Toastr -->
    <?php echo Html::script('js/plugins/toastr/toastr.min.js'); ?>


    <!-- Custom and plugin javascript -->
    <?php echo Html::script('js/inspinia.js'); ?>

    <?php echo Html::script('js/plugins/pace/pace.min.js'); ?>


    <?php echo $__env->yieldContent('customjs'); ?>


</body>

</html>
