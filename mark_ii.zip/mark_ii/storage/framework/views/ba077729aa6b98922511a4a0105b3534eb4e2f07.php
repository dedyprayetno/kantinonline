<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myModalLabel">Konfirmasi Penghapusan Data</h4>
			</div>
			<div class="modal-body">
				<p id="para">Apakah anda yakin ingin menghapus data ini?</p>
			</div>
			<div class="modal-footer">
				<a id="tombol_konfirmasi_hapus" href="#" class="btn btn-danger"><i class="fa fa-trash-o"></i> Hapus</a>
				<button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-arrow-circle-left"></i> Kembali</button>
			</div>
		</div>
	</div>
</div>