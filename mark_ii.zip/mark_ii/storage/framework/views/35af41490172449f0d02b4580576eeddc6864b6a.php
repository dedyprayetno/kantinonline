<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>$nama_situs | @judul_halaman</title>

    <?php echo Html::style ('css/plugins/iCheck/custom.css'); ?>


    <!-- Bootstrap core CSS -->
    <?php echo Html::style('css/bootstrap.css'); ?>


    <!-- Animation CSS -->
    <?php echo Html::style('css/animate.css'); ?>

    <?php echo Html::style('font-awesome/css/font-awesome.min.css'); ?>


    <!-- Custom styles for this template -->
    <?php echo Html::style('css/style.css'); ?>


</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen   animated fadeInDown">
        <div>
            <div>

                <h1 class="logo-name">PNB</h1>

            </div>
            <h3>Daftar ke Kantin Online</h3>
            <p>Buat Akun untuk dapat menggunakan kantin online</p>
            <?php if($errors->has()): ?>
            <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br />
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <?php echo Form::open(array('route' => 'registrasi', 'class' => 'm-t')); ?>

                <div class="form-group">
                    <?php echo e(Form::text('nim', null, array('class' => 'form-control','placeholder'=>'Masukan NIM/NIK/NIP'))); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::text('nama', null, array('class' => 'form-control','placeholder'=>'Masukan Nama Lengkap'))); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::text('username', null, array('class' => 'form-control','placeholder'=>'Masukan Username'))); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::email('email', null, array('class' => 'form-control','placeholder'=>'Masukan Email'))); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::password('password', array('class' => 'form-control','placeholder'=>'Masukan Password'))); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::password('password_confirmation', array('class' => 'form-control','placeholder'=>'Ulangi Password'))); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::select('jenis_kelamin', array('laki' => 'Laki-Laki', 'perempuan' => 'Perempuan'), null, array('class' => 'form-control','placeholder'=>'Pilih Jenis Kelamin'))); ?>

                </div>
                <div class="form-group">
                        <div class="checkbox i-checks"><label> <input type="checkbox"><i></i> Agree the terms and policy </label></div>
                </div>
                <button type="submit" class="btn btn-primary block full-width m-b">Register</button>

                <p class="text-muted text-center"><small>Already have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="login.html">Login</a>
            </form>
            <p class="m-t"> <small>Kantin Online using framework base on Bootstrap 3 &copy; 2016</small> </p>
        </div>
    </div>

    <!-- Mainly scripts -->
    <?php echo Html::script('js/jquery-2.1.1.js'); ?>

    <?php echo Html::script('js/bootstrap.min.js'); ?>

    <!-- iCheck -->
    <?php echo Html::script('js/plugins/iCheck/icheck.min.js'); ?>

    <script>
        $(document).ready(function(){
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
        });
    </script>
</body>

</html>
