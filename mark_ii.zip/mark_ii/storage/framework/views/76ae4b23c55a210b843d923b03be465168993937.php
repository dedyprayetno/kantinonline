<?php $__env->startSection('customcss'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>


<?php if(Session::has('pesan')): ?>
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <?php echo e(Session::get('pesan')); ?>

</div>
<?php endif; ?>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
		<div class="form-group">
		<?php echo e(Form::open(array('route' => 'simpan_member_isi_saldo', 'files'=> true))); ?>

			<?php echo e(Form::label('', 'Jumlah Saldo', array('class' => 'col-sm-4 control-label'))); ?>

			<div class="col-sm-5">
				<?php echo e(Form::text('jumlah', null, array('class' => 'form-control','placeholder'=>'masukkan Jumlah Saldo'))); ?>

			</div>
		</div>
	</div>
	<div class="row">
		<div class="form-group">
			<?php echo e(Form::label('tipe', 'Berkas Gambar', array ('class' => 'col-sm-4 control-label'))); ?>

			<div class="col-sm-5">
			 <?php echo e(Form::file('file', null, array('class'=> 'form-control'))); ?>

			</div>
		</div>
	</div>
	<?php echo csrf_field(); ?>

		<div class="form-group">
			<?php echo e(Form::submit('Simpan', array('class' => 'btn btn-primary'))); ?>

			<?php echo e(Form::close()); ?>

			<a href="<?php echo e(URL::route('beranda_member')); ?>" type="button" class="btn btn-default">
	            Kembali
	        </a>
		</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.member.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>