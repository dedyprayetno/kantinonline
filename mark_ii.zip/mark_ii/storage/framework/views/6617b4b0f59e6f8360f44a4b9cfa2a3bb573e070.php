<?php $__env->startSection('customcss'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('kepala'); ?>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah_admin">
        Tambah
</button>
<?php $__env->stopSection(); ?>
    

<?php $__env->startSection('konten'); ?>
<?php if(Session::has('pesan')): ?>
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <?php echo e(Session::get('pesan')); ?>

</div>
<?php endif; ?>
<div class="table-responsive">
<table class="table table-striped table-bordered table-hover dataTables-example">
<thead>
<tr>
    <th style="text-align:center;" width="20px">NIM/NIK/NIP</th>
    <th>Username</th>
    <th>Nama</th>
    <th>Email</th>
    <th>Saldo</th>
    <th>verifikasi</th>
    <th style="text-align:center;" width="100px">Aksi</th>
</tr>
</thead>
<tbody>
<?php foreach($pengguna as $pengguna): ?>
<?php if($pengguna->akses == "Admin"): ?><tr>
    <td><?php echo e($pengguna->nim); ?></td>
    <td><?php echo e($pengguna->username); ?></td>
    <td><?php echo e($pengguna->nama); ?></td>
    <td><?php echo e($pengguna->email); ?></td>
    <td>RP <?php echo e($pengguna->profil->pengguna_nim); ?></td>
    <td><?php echo e($pengguna->verifikasi); ?></td>
    <td></td>
      
</tr>
<?php endif; ?> 
<?php endforeach; ?>  
</tbody>
<tfoot>
<tr>
    <th style="text-align:center;" width="20px">NIM/NIK/NIP</th>
    <th>Username</th>
    <th>Nama</th>
    <th>Email</th>
    <th>Saldo</th>
    <th>verifikasi</th>
    <th style="text-align:center;" width="100px">Aksi</th>
</tr>
</tfoot>
</table>
</div>

<?php echo $__env->make('admin.manajemen_admin.tambah_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>