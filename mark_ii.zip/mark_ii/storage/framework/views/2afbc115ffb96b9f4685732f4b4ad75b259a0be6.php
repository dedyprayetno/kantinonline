<?php $__env->startSection('customcss'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>


<?php if(Session::has('pesan')): ?>
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <?php echo e(Session::get('pesan')); ?>

</div>
<?php endif; ?>
<?php foreach($menu as $menu): ?>
<?php if($menu->status == "Aktif"): ?>
<div class="col-md-3 col-sm-4 col-xs-12">
    <div class="ibox">
        <div class="ibox-content product-box">

           
            <?php if($menu->file != ""): ?>
            	<img src="<?php echo e(URL::to('/')); ?>/images/menu/<?php echo e($menu->file); ?>" class="img-responsive">
            <?php endif; ?>
            
            <div class="product-desc">
                <span class="product-price">
                    Rp <?php echo e($menu->harga); ?>

                </span>
                <small class="text-muted"><?php echo e($menu->tipe); ?></small>
                <a href="#" class="product-name"> <?php echo e($menu->nama_menu); ?></a>



                <div class="small m-t-xs">
                    <?php echo e($menu->deskripsi); ?>

                </div>
                <div class="m-t text-righ">

                    <a onClick="tambahMenu('<?php echo e(URL::route('api_tambah_keranjang', $menu->id)); ?>','<?php echo e($menu->id); ?>')"class="btn btn-xs btn-outline btn-primary">Beli <i class="fa fa-long-arrow-right"></i> </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endforeach; ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
<script type="text/javascript">
 function tambahMenu(url, id){
    console.log(id);
    $.ajax({
        method: "POST",
        url: url,
        data: {
        "_token": "<?php echo e(csrf_token()); ?>",
        "id": id
        },
        dataType: "json",
        success: function(data){
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    timeOut: 3000,
                    positionClass : 'toast-top-left'
                };
                toastr.success(data, 'Success!!');
                $('#keranjang').html(data);

            }, 1300);
            console.log(data);
            
        },
        error: function(data){
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    timeOut: 3000,
                    positionClass : 'toast-top-left'
                };
                toastr.warning(data, 'Gagal!!');

            }, 1300);
        }
    });
}
</script>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.kasir.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>