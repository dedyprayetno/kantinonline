<?php $__env->startSection('customcss'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('kepala'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

<div class="row">
  <div class="form-group">

    <?php echo e(Form::open(array('route' => array('admin_ubah_menu', $data_menu->id), 'files'=> true))); ?>

    <?php echo e(Form::label('', 'Nama Menu', array('class' => 'col-sm-4 control-label'))); ?>

    <div class="col-sm-5">
      <?php echo e(Form::text('nama_menu',  $data_menu->nama_menu, array('class' => 'form-control','placeholder'=>'masukkan Nama Menu'))); ?>

    </div>
  </div>
</div>
<div class="row">
  <div class="form-group">
    <?php echo e(Form::label('tipe', 'Tipe', array ('class' => 'col-sm-4 control-label'))); ?>

    <div class="col-sm-5">
    <?php echo e(Form::select('tipe', array('Makanan' => 'Makanan', 'Minuman' => 'Minuman', 'Cemilan' => 'Cemilan'), $data_menu->tipe, array('class' => 'form-control','placeholder'=>'Tipe Makanan'))); ?>

    </div>
  </div>
</div>
<div class="row">
  <div class="form-group">
    <?php echo e(Form::label('tipe', 'Berkas Gambar', array ('class' => 'col-sm-4 control-label'))); ?>

    <div class="col-sm-5">
     <?php echo e(Form::file('image', null, array('class'=> 'form-control'))); ?>

    </div>
  </div>
</div>
<div class="row">
  <div class="form-group">
    <?php echo e(Form::label('', 'Harga', array('class' => 'col-sm-4 control-label'))); ?>

    <div class="col-sm-5">
      <?php echo e(Form::text('harga', $data_menu->harga, array('class' => 'form-control','placeholder'=>'masukkan Harga Menu'))); ?>

    </div>
    
  </div>
</div>
<div class="row">
  <div class="form-group">
    <?php echo e(Form::label('', 'Deskripsi', array('class' => 'col-sm-4 control-label'))); ?>

    <div class="col-sm-5">
      <?php echo e(Form::textarea('deskripsi', $data_menu->deskripsi, array('class' => 'form-control','placeholder'=>'masukkan Deskripsi','rows' => '3'))); ?>

    </div>
  </div>
</div>
<div class="row">
  <div class="form-group">
    <?php echo e(Form::label('status', 'Status', array ('class' => 'col-sm-4 control-label'))); ?>

    <div class="col-sm-5">
    <?php echo e(Form::select('status', array('Aktif' => 'Aktif', 'Nonaktif' => 'Non Aktif'), $data_menu->status, array('class' => 'form-control','placeholder'=>'Status'))); ?>

    </div>
  </div>
</div>
<?php echo csrf_field(); ?>

  <div class="form-group">
    <?php echo e(Form::submit('Simpan', array('class' => 'btn btn-primary'))); ?>

    <?php echo e(Form::close()); ?>

    <a href="<?php echo e(URL::route('admin_menu')); ?>" type="button" class="btn btn-default">
            Kembali
        </a>
  </div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>