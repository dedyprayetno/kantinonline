<?php $__env->startSection('customcss'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('kepala'); ?>
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#isi_saldo_member">
        Isi Saldo
</button> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

<div class="table-responsive">
<table class="table table-striped table-bordered table-hover dataTables-example">
<thead>
<tr>
    <th style="text-align:center;" width="20px">No</th>
    <th>NIM</th>
    <th>jumlah</th>
    <th>file</th>
    <th>status konfirmasi</th>
    <th>Konfirmasi Oleh</th>
</tr>
</thead>
<tbody>
<?php $no = 1; ?>
<?php foreach($data_isi_saldo as $list_saldo): ?>
<tr>
    <td><?php echo e($no); ?></td>
    <td><?php echo e($list_saldo->nim); ?></td>
    <td><?php echo e($list_saldo->jumlah); ?></td>
    <td><?php if($list_saldo->file != ""): ?>
        <a href="<?php echo e(URL::to('/')); ?>/images/isi_saldo/<?php echo e($menu->file); ?>" target="_blank" />file</a>
        <?php endif; ?>
    </td>
    <td><?php echo e($list_saldo->status_konfirmasi); ?></td>
    <td><?php echo e($list_saldo->konfirmasi); ?></td>
        
</tr>
<?php $no++; ?>
<?php endforeach; ?>  
</tbody>
<tfoot>
<tr>
    <th style="text-align:center;" width="20px">No</th>
    <th>NIM</th>
    <th>jumlah</th>
    <th>file</th>
    <th>status konfirmasi</th>
    <th>Konfirmasi Oleh</th>
</tr>
</tfoot>
</table>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>

    <!-- <script type="text/javascript">
      function editMenu(url, nama, tipe, harga, deskripsi){
        $.ajax({
          method: "GET",
          url: url,
          dataType: "json",
          success: function(data){
            console.log(data);
            // $('#edit_menu form').attr('action', url);
            $('#edit_menu input[name=nama_menu]').val(data.nama_menu);
            $('#edit_menu input[name=url]').val("");
            $('#edit_menu select[name=tipe]').val(tipe);
            $('#edit_menu input[name=harga]').val(harga);
            $('#edit_menu textarea[name=deskripsi]').val(deskripsi);
            $('#edit_menu').modal('show');
          }
        });
      }
      $(document).ready(function(){
        $("#form_edit_menu").submit(function(event){
          event.preventDefault();
          console.log('ok');
          $.ajax({
            method: "POST",
            url: $("#form_edit_menu input[name=url").val(),
            data: $(this).serialize(),
            dataType: "json",
            success: function(data){
              console.log(data);
            }
          });
    
          // return false;
        });
      });
    </script> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>