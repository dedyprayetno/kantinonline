<?php $__env->startSection('customcss'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>


<?php if(Session::has('pesan')): ?>
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <?php echo e(Session::get('pesan')); ?>

</div>
<?php endif; ?>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
		<div class="col-lg-3">
		    <div class="widget style1 lazur-bg">
		        <div class="row">
		            <div class="col-xs-4">
		                <i class="fa fa-user fa-5x"></i>
		            </div>
		            
		        </div>
		    </div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.member.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>