<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element"> <span>
                        <img alt="image" class="img-circle" src="img/profile_small.jpg" />
                         </span>
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">{{ Auth::user()->nama }}</strong>
                         </span> <span class="text-muted text-xs block">{{ Auth::user()->akses }} <b class="caret"></b></span> </span> </a>
                    <ul class="dropdown-menu animated fadeInRight m-t-xs">
                        <li><a href="profile.html">Profile</a></li>
                        <li><a href="contacts.html">Contacts</a></li>
                        <li><a href="mailbox.html">Mailbox</a></li>
                        <li class="divider"></li>
                        <li><a href="{{ URL::route('keluar') }}">Logout</a></li>
                    </ul>
                </div>
                <div class="logo-element">
                    KO
                </div>
            </li>
            <li class="special_link">
                <a href="{{ URL::route('beranda_admin') }}"><i class="fa fa-dashboard"></i> <span class="nav-label">Beranda</span></a>
            </li>
            <li>
                <a href="{{ URL::route('admin_menu') }}"><i class="fa fa-spoon"></i> <span class="nav-label">Manajemen Menu</span></a>
            </li>
            <li>
                <a href="{{ URL::route('admin_isi_saldo')}}"><i class="fa fa-money"></i> <span class="nav-label">Isi Saldo</span></a>
            </li>
            <li>
                <a href="{{ URL::route('admin_tarik_saldo')}}"><i class="fa fa-money"></i> <span class="nav-label">Tarik Saldo</span></a>
            </li>
             <li>
                <a href="#"><i class="fa fa-book"></i> <span class="nav-label">Laporan </span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="#">Penjualan</a></li>
                    <li><a href="{{ URL::route('admin_laporan_isi_saldo')}}">Pengisian Saldo</a></li>
                    <li><a href="#">Penarikan Saldo</a></li>
                </ul>
            </li>
            <li>
                <a href="#"><i class="fa fa-users"></i> <span class="nav-label">Manajemen Pengguna </span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="{{ URL::route('admin_manajemen_admin') }}">Admin</a></li>
                    <li>
                        <a href="{{ URL::route('admin_manajemen_kasir') }}">Kasir</a></li>
                    <li>
                        <a href="#">Member</a></li>
                </ul>
            </li>
        </ul>

    </div>
</nav>