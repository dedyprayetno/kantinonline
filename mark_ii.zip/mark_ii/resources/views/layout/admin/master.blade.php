<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>{{ $judul_halaman }} | Kantin Online</title>
     <!-- Bootstrap core CSS -->
    {!! Html::style('css/bootstrap.css') !!}

    <!-- Animation CSS -->
    {!! Html::style('css/animate.css') !!}
    {!! Html::style('font-awesome/css/font-awesome.min.css') !!}

    {!! Html::style('css/plugins/dataTables/datatables.min.css') !!}

    <!-- Toastr style -->
    {!! Html::style('css/plugins/toastr/toastr.min.css') !!}

    <!-- Custom styles for this template -->
    {!! Html::style('css/style.css') !!}
    {!! Html::style('css/plugins/sweetalert/sweetalert.css') !!}

    @yield('customcss')
</head>

<body class="">

    <div id="wrapper">

        <!-- Navigasi-->
        @include('layout.admin._sidebar')

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <!-- Header-->
        @include('layout.admin._header')
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>{{ $judul_halaman }}</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="{{ URL::route('beranda_admin') }}">Admin</a>
                        </li>
                        <li class="active">
                            <strong>{{ $judul_halaman }}</strong>
                        </li>
                    </ol>
                </div>
                
            </div>

            <div class="wrapper wrapper-content animated fadeInRight">
               <div class="row">
                   <div class="col-lg-12">
                       <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                @yield('kepala')
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                            @yield('konten')
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer">
                <div class="pull-right">
                    10GB of <strong>250GB</strong> Free.
                </div>
                <div>
                    <strong>Copyright</strong> Example Company &copy; 2014-2015
                </div>
            </div>

        </div>
    </div>


    <!-- Mainly scripts -->
    {!! Html::script('js/jquery-2.1.1.js') !!}
    {!! Html::script('js/bootstrap.min.js') !!}
    {!! Html::script('js/plugins/metisMenu/jquery.metisMenu.js') !!}
    {!! Html::script('js/plugins/slimscroll/jquery.slimscroll.min.js') !!}

    {!! Html::script('js/plugins/dataTables/datatables.min.js') !!}

    <!-- Toastr -->
    {!! Html::script('js/plugins/toastr/toastr.min.js') !!}

    <!-- Custom and plugin javascript -->
    {!! Html::script('js/inspinia.js') !!}
    {!! Html::script('js/plugins/pace/pace.min.js') !!}
    {!! Html::script('js/plugins/sweetalert/sweetalert.min.js') !!}
    @yield('customjs')

    <script type="text/javascript">
        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                "language": {
            "url": "http://cdn.datatables.net/plug-ins/1.10.9/i18n/Indonesian.json",
            "sEmptyTable": "Tidak ada data di database"
        }
            });
        });
    </script>

    <script type="text/javascript">
        @if(Session::has('pesan'))
            $(document).ready(function() {
                setTimeout(function() {
                    toastr.options = {
                        closeButton: true,
                        progressBar: true,
                        showMethod: 'slideDown',
                        timeOut: 4000,
                        positionClass : 'toast-top-left'
                    };
                    toastr.success('{{ Session::get('pesan') }}', 'Success!!');

                }, 1300);
            });
        @endif
        @if($errors->has())
            $(document).ready(function() {
                    setTimeout(function() {
                        toastr.options = {
                            closeButton: true,
                            progressBar: true,
                            showMethod: 'slideDown',
                            timeOut: 4000,
                            positionClass : 'toast-top-left'
                        };
                        toastr.error('@foreach($errors->all() as $error){{ $error }}<br />@endforeach', 'Error!!');

                    }, 1300);
                });
        @endif
        </script> 
        <script type="text/javascript">
          function konfirmasiHapus(url, nama){
            swal({
                        title: "",
                        text: "Anda yakin akan menghapus " + nama + "?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Yes, delete it!",
                        cancelButtonText: "No, cancel plx!",
                        closeOnConfirm: false,
                        closeOnCancel: false },
                        function (isConfirm) {
                        if (isConfirm) {
                            swal({
                                title:"Deleted!", 
                                text:"Your imaginary file has been deleted.",
                                type: "success",
                                },

                            function() {
                                    document.location.href = url;
                            
                            });
                        }
                         else {
                            swal("Cancelled", "Your imaginary file is safe :)", "error");
                        }
                    
                });

            }

        </script>   
    

    


</body>

</html>
