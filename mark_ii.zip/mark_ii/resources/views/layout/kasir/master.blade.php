<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <title>{{ $judul_halaman }} | Kantin Online</title>
     <!-- Bootstrap core CSS -->
    {!! Html::style('css/bootstrap.css') !!}

    <!-- Animation CSS -->
    {!! Html::style('css/animate.css') !!}
    {!! Html::style('font-awesome/css/font-awesome.min.css') !!}

    {!! Html::style('css/plugins/dataTables/datatables.min.css') !!}

    <!-- Toastr style -->
    {!! Html::style('css/plugins/toastr/toastr.min.css') !!}

    <!-- Custom styles for this template -->
    {!! Html::style('css/style.css') !!}

    @yield('customcss')

</head>


<body class="canvas-menu">

    <div id="wrapper">
    <!-- Navigasi-->
    @include('layout.kasir._sidebar')

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <!-- Header-->
        @include('layout.kasir._header')
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>{{ $judul_halaman }}</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="{{URL::route('beranda_kasir')}}">Kasir</a>
                        </li>
                        <li class="active">
                            <strong>{{ $judul_halaman }}</strong>
                        </li>
                    </ol>
                </div>
            </div>

            <div class="wrapper wrapper-content  animated fadeInRight article">
                <div class="row">
                     @yield('konten')
                </div>


            </div>
            <div class="footer">
                <div class="pull-right">
                    
                </div>
                <div>
                    <strong>Copyright</strong> DKP Industries &copy; 2016-2017
                </div>
            </div>

        </div>
        </div>

    <!-- Mainly scripts -->

    <!-- Mainly scripts -->
    {!! Html::script('js/jquery-2.1.1.js') !!}
    {!! Html::script('js/bootstrap.min.js') !!}
    {!! Html::script('js/plugins/metisMenu/jquery.metisMenu.js') !!}
    {!! Html::script('js/plugins/slimscroll/jquery.slimscroll.min.js') !!}

    <!-- Custom and plugin javascript -->
    {!! Html::script('js/inspinia.js') !!}
    {!! Html::script('js/plugins/pace/pace.min.js') !!}

    {!! Html::script('js/plugins/dataTables/datatables.min.js') !!}

    <!-- Toastr -->
    {!! Html::script('js/plugins/toastr/toastr.min.js') !!}


    <script>
        $('body.canvas-menu .sidebar-collapse').slimScroll({
                        height: '100%',
                        railOpacity: 0.9
                    });
    </script>

    <script type="text/javascript">
        @if(Session::has('pesan'))
            $(document).ready(function() {
                setTimeout(function() {
                    toastr.options = {
                        closeButton: true,
                        progressBar: true,
                        showMethod: 'slideDown',
                        timeOut: 4000,
                        positionClass : 'toast-top-left'
                    };
                    toastr.success('{{ Session::get('pesan') }}', 'Success!!');

                }, 1300);
            });
        @endif
        @if(Session::has('error'))
            $(document).ready(function() {
                    setTimeout(function() {
                        toastr.options = {
                            closeButton: true,
                            progressBar: true,
                            showMethod: 'slideDown',
                            timeOut: 4000,
                            positionClass : 'toast-top-left'
                        };
                        toastr.error('{{ Session::get('error') }}', 'Error!!');

                    }, 1300);
                });
        @endif
        </script>

        <script type="text/javascript">
            function lihatKeranjang(url){
                $.ajax({
                  method: "GET",
                  url: url,
                  dataType: "json",
                  success: function(data){
                    console.log(data.total);
                  }
                });
            }
        </script>

    @yield('customjs')

</body>

</html>
