<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <title>{{ $judul_halaman }} | Kantin Online</title>
     <!-- Bootstrap core CSS -->
    {!! Html::style('css/bootstrap.css') !!}

    <!-- Animation CSS -->
    {!! Html::style('css/animate.css') !!}
    {!! Html::style('font-awesome/css/font-awesome.min.css') !!}

    {!! Html::style('css/plugins/dataTables/datatables.min.css') !!}

    <!-- Toastr style -->
    {!! Html::style('css/plugins/toastr/toastr.min.css') !!}

    <!-- Custom styles for this template -->
    {!! Html::style('css/style.css') !!}
    {!! Html::style('css/plugins/codemirror/codemirror.css')!!}
    {!! Html::style('css/plugins/codemirror/ambiance.css')!!}

    @yield('customcss')
    

</head>

<body class="fixed-sidebar no-skin-config full-height-layout">

    <div id="wrapper">

    @include('layout.member._sidebar')

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        @include('layout.member._header')
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Outlook view</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Layouts</a>
                        </li>
                        <li class="active">
                            <strong>Outlook view</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>

                 <div class="wrapper wrapper-content animated fadeInRight">
                   <div class="row">
                       <div class="col-lg-12">
                           <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    @yield('kepala')
                                    <div class="ibox-tools">
                                        <a class="collapse-link">
                                            <i class="fa fa-chevron-up"></i>
                                        </a>
                                        <a class="close-link">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="ibox-content">
                                @yield('konten')
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



            </div>

        <div class="footer">
            <div class="pull-right">
                10GB of <strong>250GB</strong> Free.
            </div>
            <div>
                <strong>Copyright</strong> Example Company &copy; 2016
            </div>
        </div>

        </div>
        </div>



    <!-- Mainly scripts -->
    {!! Html::script('js/jquery-2.1.1.js') !!}
    {!! Html::script('js/bootstrap.min.js') !!}
    {!! Html::script('js/plugins/metisMenu/jquery.metisMenu.js') !!}
    {!! Html::script('js/plugins/slimscroll/jquery.slimscroll.min.js') !!}

    {!! Html::script('js/plugins/dataTables/datatables.min.js') !!}

    <!-- Toastr -->
    {!! Html::script('js/plugins/toastr/toastr.min.js') !!}

    <!-- Custom and plugin javascript -->
    {!! Html::script('js/inspinia.js') !!}
    {!! Html::script('js/plugins/pace/pace.min.js') !!}

    @yield('customjs')


</body>

</html>
