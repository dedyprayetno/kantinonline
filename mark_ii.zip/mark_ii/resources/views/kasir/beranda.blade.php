@extends('layout.kasir.master')
@section ('customcss')

@endsection

@section('konten')


@if(Session::has('pesan'))
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    {{ Session::get('pesan') }}
</div>
@endif
@foreach($menu as $menu)
@if($menu->status == "Aktif")
<div class="col-md-3 col-sm-4 col-xs-12">
    <div class="ibox">
        <div class="ibox-content product-box">

           
            @if($menu->file != "")
            	<img src="{{ URL::to('/') }}/images/menu/{{ $menu->file }}" class="img-responsive">
            @endif
            
            <div class="product-desc">
                <span class="product-price">
                    Rp {{ $menu->harga }}
                </span>
                <small class="text-muted">{{ $menu->tipe }}</small>
                <a href="#" class="product-name"> {{ $menu->nama_menu }}</a>



                <div class="small m-t-xs">
                    {{ $menu->deskripsi }}
                </div>
                <div class="m-t text-righ">

                    <a onClick="tambahMenu('{{ URL::route('api_tambah_keranjang', $menu->id) }}','{{$menu->id}}')"class="btn btn-xs btn-outline btn-primary">Beli <i class="fa fa-long-arrow-right"></i> </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endif
@endforeach


@endsection
@section('customjs')
<script type="text/javascript">
 function tambahMenu(url, id){
    console.log(id);
    $.ajax({
        method: "POST",
        url: url,
        data: {
        "_token": "{{ csrf_token() }}",
        "id": id
        },
        dataType: "json",
        success: function(data){
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    timeOut: 3000,
                    positionClass : 'toast-top-left'
                };
                toastr.success(data, 'Success!!');
                $('#keranjang').html(data);

            }, 1300);
            console.log(data);
            
        },
        error: function(data){
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    timeOut: 3000,
                    positionClass : 'toast-top-left'
                };
                toastr.warning(data, 'Gagal!!');

            }, 1300);
        }
    });
}
</script>
	
@endsection