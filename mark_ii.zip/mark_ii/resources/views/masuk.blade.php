<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>{{ $judul_halaman }} | {{ $nama_situs }}</title>

    <!-- Bootstrap core CSS -->
    {!! Html::style('css/bootstrap.css') !!}

    <!-- Animation CSS -->
    {!! Html::style('css/animate.css') !!}
    {!! Html::style('font-awesome/css/font-awesome.min.css') !!}

    <!-- Custom styles for this template -->
    {!! Html::style('css/style.css') !!}

</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>

                <h1 class="logo-name">PNB</h1>

            </div>
            <h3>Selamat datang di Kantin Online</h3>
            <p>Mari gunakan teknologi untuk mempermudah kita
                <!--Continually expanded and constantly improved Inspinia Admin Them (IN+)-->
            </p>
            <p>asukkan email dan kata sandi anda.</p>
            @if($errors->has())
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                @foreach($errors->all() as $error)
                    {{ $error }}<br />
                @endforeach
            </div>
            @endif
            @if(Session::has('pesan'))
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              {{ Session::get('pesan') }}
            </div>
            @endif
            {!! Form::open(array('route' => 'otorisasi', 'class' => 'm-t')) !!}
                <div class="form-group">
                    {!! Form::text('username', null, array('class' => 'form-control', 'placeholder' => 'Username atau Email')) !!}
                </div>
                <div class="form-group">
                    {!! Form::password('password', array('class' => 'form-control', 'placeholder' => 'Kata Sandi')) !!}
                </div>
                {!! csrf_field() !!}
                <button type="submit" class="btn btn-primary block full-width m-b">Login</button>

                <a href="#"><small>Forgot password?</small></a>
                <p class="text-muted text-center"><small>Do not have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="{{ URL::route('daftar') }}">Create an account</a>
            {!! Form::close() !!}
            <p class="m-t"> <small>Kantin Online using framework base on Bootstrap 3 &copy; 2016</small> </p>
        </div>
    </div>

    <!-- Mainly scripts -->
    {!! Html::script('js/jquery-2.1.1.js') !!}
    {!! Html::script('js/bootstrap.min.js') !!}

</body>

</html>
