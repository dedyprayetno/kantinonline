@extends('layout.member.master')
@section ('customcss')

@endsection

@section('konten')


@if(Session::has('pesan'))
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    {{ Session::get('pesan') }}
</div>
@endif
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
		<div class="form-group">
		{{ Form::open(array('route' => 'simpan_member_isi_saldo', 'files'=> true)) }}
			{{ Form::label('', 'Jumlah Saldo', array('class' => 'col-sm-4 control-label')) }}
			<div class="col-sm-5">
				{{ Form::text('jumlah', null, array('class' => 'form-control','placeholder'=>'masukkan Jumlah Saldo')) }}
			</div>
		</div>
	</div>
	<div class="row">
		<div class="form-group">
			{{ Form::label('tipe', 'Berkas Gambar', array ('class' => 'col-sm-4 control-label')) }}
			<div class="col-sm-5">
			 {{ Form::file('file', null, array('class'=> 'form-control')) }}
			</div>
		</div>
	</div>
	{!! csrf_field() !!}
		<div class="form-group">
			{{ Form::submit('Simpan', array('class' => 'btn btn-primary')) }}
			{{ Form::close() }}
			<a href="{{ URL::route('beranda_member') }}" type="button" class="btn btn-default">
	            Kembali
	        </a>
		</div>


@endsection
@section('customjs')
	
@endsection