@extends('layout.admin.master')
@section ('customcss')

@endsection


@section('kepala')
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah_admin">
        Tambah
</button>
@endsection
    

@section('konten')
@if(Session::has('pesan'))
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    {{ Session::get('pesan') }}
</div>
@endif
<div class="table-responsive">
<table class="table table-striped table-bordered table-hover dataTables-example">
<thead>
<tr>
    <th style="text-align:center;" width="20px">NIM/NIK/NIP</th>
    <th>Username</th>
    <th>Nama</th>
    <th>Email</th>
    <th>Saldo</th>
    <th>verifikasi</th>
    <th style="text-align:center;" width="100px">Aksi</th>
</tr>
</thead>
<tbody>
@foreach($pengguna as $pengguna)
@if ($pengguna->akses == "Admin")<tr>
    <td>{{ $pengguna->nim }}</td>
    <td>{{ $pengguna->username }}</td>
    <td>{{ $pengguna->nama }}</td>
    <td>{{ $pengguna->email }}</td>
    <td>RP {{ $pengguna->profil->pengguna_nim}}</td>
    <td>{{ $pengguna->verifikasi }}</td>
    <td></td>
      
</tr>
@endif 
@endforeach  
</tbody>
<tfoot>
<tr>
    <th style="text-align:center;" width="20px">NIM/NIK/NIP</th>
    <th>Username</th>
    <th>Nama</th>
    <th>Email</th>
    <th>Saldo</th>
    <th>verifikasi</th>
    <th style="text-align:center;" width="100px">Aksi</th>
</tr>
</tfoot>
</table>
</div>

@include('admin.manajemen_admin.tambah_admin')
@endsection

@section('customjs')
  
@endsection