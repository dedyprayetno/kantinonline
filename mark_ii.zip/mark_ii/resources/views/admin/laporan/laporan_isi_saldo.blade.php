@extends('layout.admin.master')
@section ('customcss')

@endsection


@section('kepala')
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#isi_saldo_member">
        Isi Saldo
</button> -->
@endsection

@section('konten')

<div class="table-responsive">
<table class="table table-striped table-bordered table-hover dataTables-example">
<thead>
<tr>
    <th style="text-align:center;" width="20px">No</th>
    <th>NIM</th>
    <th>jumlah</th>
    <th>file</th>
    <th>status konfirmasi</th>
    <th>Konfirmasi Oleh</th>
</tr>
</thead>
<tbody>
<?php $no = 1; ?>
@foreach($data_isi_saldo as $list_saldo)
<tr>
    <td>{{{ $no }}}</td>
    <td>{{ $list_saldo->nim }}</td>
    <td>{{ $list_saldo->jumlah }}</td>
    <td>@if ($list_saldo->file != "")
        <a href="{{ URL::to('/') }}/images/isi_saldo/{{ $menu->file }}" target="_blank" />file</a>
        @endif
    </td>
    <td>{{ $list_saldo->status_konfirmasi }}</td>
    <td>{{ $list_saldo->konfirmasi }}</td>
        
</tr>
<?php $no++; ?>
@endforeach  
</tbody>
<tfoot>
<tr>
    <th style="text-align:center;" width="20px">No</th>
    <th>NIM</th>
    <th>jumlah</th>
    <th>file</th>
    <th>status konfirmasi</th>
    <th>Konfirmasi Oleh</th>
</tr>
</tfoot>
</table>
</div>


@endsection

@section('customjs')

    <!-- <script type="text/javascript">
      function editMenu(url, nama, tipe, harga, deskripsi){
        $.ajax({
          method: "GET",
          url: url,
          dataType: "json",
          success: function(data){
            console.log(data);
            // $('#edit_menu form').attr('action', url);
            $('#edit_menu input[name=nama_menu]').val(data.nama_menu);
            $('#edit_menu input[name=url]').val("");
            $('#edit_menu select[name=tipe]').val(tipe);
            $('#edit_menu input[name=harga]').val(harga);
            $('#edit_menu textarea[name=deskripsi]').val(deskripsi);
            $('#edit_menu').modal('show');
          }
        });
      }
      $(document).ready(function(){
        $("#form_edit_menu").submit(function(event){
          event.preventDefault();
          console.log('ok');
          $.ajax({
            method: "POST",
            url: $("#form_edit_menu input[name=url").val(),
            data: $(this).serialize(),
            dataType: "json",
            success: function(data){
              console.log(data);
            }
          });
    
          // return false;
        });
      });
    </script> -->

@endsection