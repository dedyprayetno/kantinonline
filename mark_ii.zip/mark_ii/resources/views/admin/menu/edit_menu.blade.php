@extends('layout.admin.master')
@section ('customcss')

@endsection


@section('kepala')

@endsection

@section('konten')

<div class="row">
  <div class="form-group">
    {{ Form::open(array('route' => array('admin_ubah_menu', $data_menu->id), 'files'=> true)) }}
    {{ Form::label('', 'Nama Menu', array('class' => 'col-sm-4 control-label')) }}
    <div class="col-sm-5">
      {{ Form::text('nama_menu',  $data_menu->nama_menu, array('class' => 'form-control','placeholder'=>'masukkan Nama Menu')) }}
    </div>
  </div>
</div>
<div class="row">
  <div class="form-group">
    {{ Form::label('tipe', 'Tipe', array ('class' => 'col-sm-4 control-label')) }}
    <div class="col-sm-5">
    {{ Form::select('tipe', array('Makanan' => 'Makanan', 'Minuman' => 'Minuman', 'Cemilan' => 'Cemilan'), $data_menu->tipe, array('class' => 'form-control','placeholder'=>'Tipe Makanan')) }}
    </div>
  </div>
</div>
<div class="row">
  <div class="form-group">
    {{ Form::label('tipe', 'Berkas Gambar', array ('class' => 'col-sm-4 control-label')) }}
    <div class="col-sm-5">
     {{ Form::file('image', null, array('class'=> 'form-control')) }}
    </div>
  </div>
</div>
<div class="row">
  <div class="form-group">
    {{ Form::label('', 'Harga', array('class' => 'col-sm-4 control-label')) }}
    <div class="col-sm-5">
      {{ Form::text('harga', $data_menu->harga, array('class' => 'form-control','placeholder'=>'masukkan Harga Menu')) }}
    </div>
    
  </div>
</div>
<div class="row">
  <div class="form-group">
    {{ Form::label('', 'Deskripsi', array('class' => 'col-sm-4 control-label')) }}
    <div class="col-sm-5">
      {{ Form::textarea('deskripsi', $data_menu->deskripsi, array('class' => 'form-control','placeholder'=>'masukkan Deskripsi','rows' => '3')) }}
    </div>
  </div>
</div>
<div class="row">
  <div class="form-group">
    {{ Form::label('status', 'Status', array ('class' => 'col-sm-4 control-label')) }}
    <div class="col-sm-5">
    {{ Form::select('status', array('Aktif' => 'Aktif', 'Nonaktif' => 'Non Aktif'), $data_menu->status, array('class' => 'form-control','placeholder'=>'Status')) }}
    </div>
  </div>
</div>
{!! csrf_field() !!}
  <div class="form-group">
    {{ Form::submit('Simpan', array('class' => 'btn btn-primary')) }}
    {{ Form::close() }}
    <a href="{{ URL::route('admin_menu') }}" type="button" class="btn btn-default">
            Kembali
        </a>
  </div>



@endsection

@section('customjs')



@endsection