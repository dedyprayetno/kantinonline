@extends('layout.admin.master')
@section ('customcss')

@endsection


@section('kepala')
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah_menu">
        Tambah
</button>
@endsection

@section('konten')

<div class="table-responsive">
<table class="table table-striped table-bordered table-hover dataTables-example datatables">
<thead>
<tr>
    <th style="text-align:center;" width="20px">No</th>
    <th>Nama</th>
    <th>Tipe</th>
    <th>Image</th>
    <th>Harga</th>
    <th>Konfirmasi Oleh</th>
    <th>Status</th>
    <th>Aksi</th>
</tr>
</thead>
<tbody>
<?php $no = 1; ?>
@foreach($data_menu as $menu)
<tr>
    <td>{{{ $no }}}</td>
    <td>{{ $menu->nama_menu }}</td>
    <td>{{ $menu->tipe }}</td>
    <td>@if ($menu->file != "")
        <a href="{{ URL::to('/') }}/images/menu/{{ $menu->file }}" target="_blank" />image</a>
        @endif
        </td>
    <td>Rp {{ $menu->harga }}</td>
    <td>{{ $menu->approve }}</td>
    <td>{{ $menu->status }}</td>
    <td>  <a href="{{ URL::route('admin_edit_menu', $menu->id) }}" class="btn btn-warning"><i class="fa fa-edit"></i> edit</a>
          <a onClick="konfirmasiHapus('{{ URL::route('admin_hapus_menu', $menu->id) }}', '{{$menu->nama_menu}}')" class="btn btn-danger"><i class="fa fa-trash-o"></i> Hapus</a></td>
        
</tr>
<?php $no++; ?>
@endforeach  
</tbody>
<tfoot>
<tr>
    <th style="text-align:center;" width="20px">No</th>
    <th>Nama</th>
    <th>Tipe</th>
    <th>Image</th>
    <th>Harga</th>
    <th>Konfirmasi Oleh</th>
    <th>Status</th>
    <th>Aksi</th>
</tr>
</tfoot>
</table>
</div>


@include('admin.menu.tambah_menu')


@endsection

@section('customjs')

    <!-- <script type="text/javascript">
      function editMenu(url, nama, tipe, harga, deskripsi){
        $.ajax({
          method: "GET",
          url: url,
          dataType: "json",
          success: function(data){
            console.log(data);
            // $('#edit_menu form').attr('action', url);
            $('#edit_menu input[name=nama_menu]').val(data.nama_menu);
            $('#edit_menu input[name=url]').val("");
            $('#edit_menu select[name=tipe]').val(tipe);
            $('#edit_menu input[name=harga]').val(harga);
            $('#edit_menu textarea[name=deskripsi]').val(deskripsi);
            $('#edit_menu').modal('show');
          }
        });
      }
      $(document).ready(function(){
        $("#form_edit_menu").submit(function(event){
          event.preventDefault();
          console.log('ok');
          $.ajax({
            method: "POST",
            url: $("#form_edit_menu input[name=url").val(),
            data: $(this).serialize(),
            dataType: "json",
            success: function(data){
              console.log(data);
            }
          });
    
          // return false;
        });
      });
    </script> -->

@endsection