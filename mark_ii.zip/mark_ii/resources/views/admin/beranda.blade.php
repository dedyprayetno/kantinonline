@extends('layout.admin.master')
@section ('customcss')

@endsection

@section('konten')


@if(Session::has('pesan'))
<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    {{ Session::get('pesan') }}
</div>
@endif
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
		<div class="col-lg-3">
		    <div class="widget style1 lazur-bg">
		        <div class="row">
		            <div class="col-xs-4">
		                <i class="fa fa-user fa-5x"></i>
		            </div>
		            <div class="col-xs-8 text-right">
		                <span> Admin </span>
		                <h2 class="font-bold">{{ $jumlah_admin }}</h2>
		            </div>
		        </div>
		    </div>
		</div>
		<div class="col-lg-3">
		    <div class="widget style1 lazur-bg">
		        <div class="row">
		            <div class="col-xs-4">
		                <i class="fa fa-user fa-5x"></i>
		            </div>
		            <div class="col-xs-8 text-right">
		                <span> Kasir </span>
		                <h2 class="font-bold">{{ $jumlah_kasir }}</h2>
		            </div>
		        </div>
		    </div>
		</div>
		<div class="col-lg-3">
		    <div class="widget style1 lazur-bg">
		        <div class="row">
		            <div class="col-xs-4">
		                <i class="fa fa-user fa-5x"></i>
		            </div>
		            <div class="col-xs-8 text-right">
		                <span> Member </span>
		                <h2 class="font-bold">{{ $jumlah_member }}</h2>
		            </div>
		        </div>
		    </div>
		</div>
	</div>
</div>


@endsection
@section('customjs')
	
@endsection